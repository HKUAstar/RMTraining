import os
import sys
import cv2 as cv
import numpy as np
import yaml
import math

class Detector:
    def __init__(self, detect_color: str, yaml_path: str):
        self.detect_color = detect_color
        with open(yaml_path, 'r') as file:
            parameters = yaml.safe_load(file)
        self.min_red = parameters['min_red']
        self.max_red = parameters['max_red']
        self.min_yellow = parameters['min_yellow']
        self.max_yellow = parameters['max_yellow']
        #Add more parameters here
    def detect(self, img: np.ndarray):
        if img is None:
            raise ValueError("图像读取失败，请检查路径")
        #-----Image Preprocessing-----#
        hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)
        #-----Color Detection-----#
        if self.detect_color == "red":
            lower1 = np.array(self.min_red)  # 红下
            upper1 = np.array(self.max_red)  # 红上
            lower2 = np.array([160, 100, 100])  
            upper2 = np.array([180, 255, 255]) 
            mask1 = cv.inRange(hsv, lower1, upper1)  
            mask2 = cv.inRange(hsv, lower2, upper2)  
            mask = cv.bitwise_or(mask1, mask2)  
        elif self.detect_color == "yellow":
            lower = np.array(self.min_yellow)  # 黄下
            upper = np.array(self.max_yellow)  # 黄上
            mask = cv.inRange(hsv, lower, upper)  
        else:
            raise ValueError("Invalid color")  

        #Modify your parameters so that the mask include as much of the ring as possible
        #while excluding as much of the environment as possible.
        if self.detect_color == "red":
            kernel = np.ones((5, 5), np.uint8)  # 创建一个 5x5 的卷积核
            mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)  # 先进行闭运算
            mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)  # 再进行开运算
        elif self.detect_color == "yellow":
            kernel = np.ones((5, 5), np.uint8)  # 创建一个 5x5 的卷积核
            mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, kernel)  # 先进行闭运算
            mask = cv.morphologyEx(mask, cv.MORPH_OPEN, kernel)  # 再进行开运算
        else:
            raise ValueError("Invalid color")
        #Optional: Add mask processing here

        #-----Mask Visualization: for Debug, Comment this before autotesting/submission!-----#
        cv.imshow("mask", mask)
        cv.waitKey(0)
        cv.destroyAllWindows()
        #-----Find countours-----#
        contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        #-----Find Objectives-----#
        objectives = []
        for contour in contours:
            (x, y), radius = cv.minEnclosingCircle(contour)
            if radius > 10:  
                objectives.append(((int(x), int(y)), int(radius)))
            #Hint: There are more than 1 ways to find circles, try them out and compare the results.
            #Your code here
        
        #-----Objectives Postprocessing-----#
        #Hint: objectives are RINGS. How to determine if overlapping circles are representing the same ring?
        #Your code here
        return objectives #each objective should be ((x,y), area). Since area is not required, if you did not include it in your code, you can return ((x,y), 0) instead.

if __name__ == '__main__':
    #File input subject to change if not using Linux
    args = sys.argv
    if len(args) > 1:
        filename = args[1]
    else:
        filename = "images/Image1.png" 
    if len(args) > 2:
        detect_color = args[2]
    else:
        detect_color = "red"
    detector = Detector(detect_color, "parameters.yaml")
    image = cv.imread(filename)
    objectives = detector.detect(image)
    for ring in objectives:
        print(ring[0][0], ring[0][1])
    #---------Visualization---------#
    VisualizeResult= True #Set to False when autotesting/before submission!
    if not VisualizeResult:
        exit()
    for ring in objectives:
        cv.circle(image, ring[0], 5, (0, 255, 0), -1)
        cv.circle(image, ring[0], int(math.sqrt(ring[1]/3.14)), (255, 0, 0), 2)
    cv.imshow("image", image)
    cv.waitKey(0)
    cv.destroyAllWindows()
    